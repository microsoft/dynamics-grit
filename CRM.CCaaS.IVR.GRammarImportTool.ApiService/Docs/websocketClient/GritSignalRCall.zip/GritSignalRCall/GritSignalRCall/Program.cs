﻿using System;
using System.IO;
using System.IO.Compression;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR.Client;
using System.Collections.Generic;

class Program
{
    static async Task Main(string[] args)
    {
        string zipFilePath = @"C:\PATH_TO_ZIP\archive.zip";

        string hubUrl = "http://localhost:5003/grithub";

        // Read the zip file as a byte array
        byte[] zipBytes = await File.ReadAllBytesAsync(zipFilePath);

        // Create and configure the SignalR connection
        var connection = new HubConnectionBuilder()
            .WithUrl(hubUrl, options =>
            {
                options.CloseTimeout = TimeSpan.FromMinutes(10);
            })
            .Build();

        DateTime connectionStartTime = DateTime.MinValue;

        connection.On<string>("ConnectionId", id =>
        {
            Console.WriteLine($"Connected with ConnectionId: {id}");
        });

        var initialProcessingTime = DateTime.Now;

        // Add this at the top of Main, after variable declarations
        string progressLogPath = Path.Combine("C:/temp/", $"progress_log_{DateTime.Now:yyyyMMdd_HHmmss}.txt");
        Directory.CreateDirectory("C:/temp/"); // Ensure directory exists

        connection.On<int, string>("Progress", (progress, message) =>
        {
            string elapsed = initialProcessingTime != DateTime.MinValue
                ? (DateTime.Now - initialProcessingTime).ToString(@"hh\:mm\:ss\.fff")
                : "N/A";
            string logMsg = $"Progress: {progress}% - {message} (Processing duration: {elapsed})";
            Console.WriteLine(logMsg);
            initialProcessingTime = DateTime.Now; // Update the initial processing time for next progress

            // Append progress message to log file
            try
            {
                File.AppendAllText(progressLogPath, logMsg + Environment.NewLine);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to write progress log: {ex.Message}");
            }
        });

        connection.On<byte[]>("Completed", async resultBytes =>
        {
            Console.WriteLine("Processing completed. Received result zip as byte array.");
            if (connectionStartTime != DateTime.MinValue)
            {
                var totalElapsed = DateTime.Now - connectionStartTime;
                Console.WriteLine($"Total processing time (connection start to completed): {totalElapsed:g}");
            }
            // Save the zip file to c:/temp/ with a unique name
            try
            {
                var tempDir = "C:/temp/";
                if (!Directory.Exists(tempDir))
                {
                    Directory.CreateDirectory(tempDir);
                }
                string uniqueId = Guid.NewGuid().ToString();
                string fileName = $"grit_{uniqueId}_{Guid.NewGuid():N}.zip";
                string filePath = Path.Combine(tempDir, fileName);
                await File.WriteAllBytesAsync(filePath, resultBytes);
                Console.WriteLine($"Zip file saved to: {filePath}");

                // Print time elapsed for each processed file in the zip
                using (var ms = new MemoryStream(resultBytes))
                using (var archive = new ZipArchive(ms, ZipArchiveMode.Read))
                {
                    int index = 1;
                    var fileTimes = new Dictionary<string, DateTime>();
                    foreach (var entry in archive.Entries)
                    {
                        var start = DateTime.Now;
                        using (var entryStream = entry.Open())
                        using (var mem = new MemoryStream())
                        {
                            await entryStream.CopyToAsync(mem);
                        }
                        var elapsed = DateTime.Now - start;
                        Console.WriteLine($"[{index}] Processed file: {entry.FullName} - Time elapsed: {elapsed.TotalMilliseconds} ms");
                        index++;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to save or process zip file: {ex.Message}");
            }
            finally
            {
                await connection.StopAsync();
                Console.WriteLine("SignalR connection closed after processing completed.");
            }
        });

        connection.On<string>("Error", error =>
        {
            Console.WriteLine($"Error: {error}");
        });

        await connection.StartAsync();
        connectionStartTime = DateTime.Now;
        Console.WriteLine("SignalR connection started.");

        // Call the UploadZipFile method with the byte array
        // Increase connection timeout to 10 minutes
        connection.ServerTimeout = TimeSpan.FromMinutes(40);
        connection.KeepAliveInterval = TimeSpan.FromMinutes(5);

        await connection.InvokeAsync("GrxmlZipConvert", zipBytes);
        Console.WriteLine("GrxmlZipConvert invoked.");

        // Keep the app running to receive events
        Console.WriteLine("Press Enter to exit...");
        Console.ReadLine();
        await connection.StopAsync();
    }
}
